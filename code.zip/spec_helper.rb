require "rack/test"
require "securerandom"
require 'securerandom'
require 'nokogiri'

RSpec.configure do |config|
  config.include Rack::Test::Methods
end

